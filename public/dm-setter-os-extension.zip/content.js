(function () {
  'use strict';

  const APP_URL = 'https://app.lovable.app/projects/dm-setter-os';

  // Avoid double-injecting
  if (document.getElementById('dm-setter-os-sidebar')) return;

  // ── Styles ──────────────────────────────────────────────────────────────────
  const style = document.createElement('style');
  style.textContent = `
    #dm-setter-os-sidebar {
      position: fixed;
      bottom: 80px;
      right: 0;
      z-index: 2147483647;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 6px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    }
    #dm-setter-os-sidebar .dms-panel {
      background: #18181b;
      border: 1px solid #3f3f46;
      border-right: none;
      border-radius: 10px 0 0 10px;
      padding: 10px 14px;
      color: #fafafa;
      min-width: 200px;
      box-shadow: -4px 4px 16px rgba(0,0,0,0.5);
      display: none;
    }
    #dm-setter-os-sidebar.open .dms-panel {
      display: block;
    }
    #dm-setter-os-sidebar .dms-toggle {
      background: linear-gradient(135deg, #6366f1, #8b5cf6);
      border: none;
      border-right: none;
      border-radius: 8px 0 0 8px;
      color: #fff;
      padding: 10px 12px;
      cursor: pointer;
      font-size: 18px;
      line-height: 1;
      box-shadow: -2px 2px 8px rgba(99,102,241,0.5);
      transition: background 0.2s;
    }
    #dm-setter-os-sidebar .dms-toggle:hover {
      background: linear-gradient(135deg, #4f46e5, #7c3aed);
    }
    .dms-title {
      font-size: 12px;
      font-weight: 700;
      color: #a78bfa;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      margin-bottom: 8px;
    }
    .dms-kpi-row {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      color: #d4d4d8;
      margin-bottom: 4px;
    }
    .dms-kpi-row span:last-child {
      color: #a78bfa;
      font-weight: 600;
    }
    .dms-divider {
      border: none;
      border-top: 1px solid #3f3f46;
      margin: 8px 0;
    }
    .dms-btn {
      display: block;
      width: 100%;
      background: #6366f1;
      color: #fff;
      border: none;
      border-radius: 6px;
      padding: 7px 10px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      text-align: center;
      text-decoration: none;
      margin-bottom: 6px;
      transition: background 0.2s;
      box-sizing: border-box;
    }
    .dms-btn:hover { background: #4f46e5; }
    .dms-btn.secondary {
      background: #27272a;
      border: 1px solid #3f3f46;
    }
    .dms-btn.secondary:hover { background: #3f3f46; }
    .dms-quick-log {
      display: flex;
      gap: 6px;
      margin-top: 6px;
    }
    .dms-input {
      flex: 1;
      background: #27272a;
      border: 1px solid #3f3f46;
      border-radius: 6px;
      color: #fafafa;
      font-size: 12px;
      padding: 6px 8px;
      outline: none;
    }
    .dms-input::placeholder { color: #71717a; }
    .dms-input:focus { border-color: #6366f1; }
    .dms-add-btn {
      background: #6366f1;
      border: none;
      border-radius: 6px;
      color: #fff;
      font-size: 12px;
      font-weight: 700;
      padding: 6px 10px;
      cursor: pointer;
    }
    .dms-add-btn:hover { background: #4f46e5; }
    .dms-no-goals {
      font-size: 11px;
      color: #71717a;
      font-style: italic;
    }
  `;
  document.head.appendChild(style);

  // ── KPI helpers ──────────────────────────────────────────────────────────────
  function getKpiGoals() {
    try {
      const raw = localStorage.getItem('dm_setter_kpi_goals');
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }

  function renderKpi(container) {
    const goals = getKpiGoals();
    container.innerHTML = '';
    if (!goals || Object.keys(goals).length === 0) {
      const p = document.createElement('p');
      p.className = 'dms-no-goals';
      p.textContent = 'No KPI goals set yet. Open the app to configure.';
      container.appendChild(p);
      return;
    }
    Object.entries(goals).forEach(([key, val]) => {
      const row = document.createElement('div');
      row.className = 'dms-kpi-row';
      row.innerHTML = `<span>${key}</span><span>${val}</span>`;
      container.appendChild(row);
    });
  }

  // ── Build sidebar ─────────────────────────────────────────────────────────────
  const sidebar = document.createElement('div');
  sidebar.id = 'dm-setter-os-sidebar';

  // Panel
  const panel = document.createElement('div');
  panel.className = 'dms-panel';

  const title = document.createElement('div');
  title.className = 'dms-title';
  title.textContent = '📊 DM Setter OS';
  panel.appendChild(title);

  const kpiContainer = document.createElement('div');
  renderKpi(kpiContainer);
  panel.appendChild(kpiContainer);

  const hr = document.createElement('hr');
  hr.className = 'dms-divider';
  panel.appendChild(hr);

  // Open app button
  const openBtn = document.createElement('a');
  openBtn.className = 'dms-btn';
  openBtn.href = APP_URL;
  openBtn.target = '_blank';
  openBtn.rel = 'noopener';
  openBtn.textContent = '🚀 Open DM Setter OS';
  panel.appendChild(openBtn);

  // Quick log
  const logTitle = document.createElement('div');
  logTitle.className = 'dms-title';
  logTitle.style.marginTop = '4px';
  logTitle.textContent = '⚡ Quick Log Lead';
  panel.appendChild(logTitle);

  const quickLogRow = document.createElement('div');
  quickLogRow.className = 'dms-quick-log';

  const handleInput = document.createElement('input');
  handleInput.className = 'dms-input';
  handleInput.placeholder = '@handle';
  handleInput.type = 'text';
  quickLogRow.appendChild(handleInput);

  const addBtn = document.createElement('button');
  addBtn.className = 'dms-add-btn';
  addBtn.textContent = '→';
  addBtn.title = 'Add as lead';
  addBtn.addEventListener('click', () => {
    const handle = handleInput.value.trim().replace(/^@/, '');
    if (!handle) return;
    const url = `${APP_URL}?new_prospect=1&handle=${encodeURIComponent(handle)}`;
    window.open(url, '_blank', 'noopener');
    handleInput.value = '';
  });
  quickLogRow.appendChild(addBtn);
  panel.appendChild(quickLogRow);

  // Toggle button
  const toggle = document.createElement('button');
  toggle.className = 'dms-toggle';
  toggle.title = 'DM Setter OS';
  toggle.innerHTML = '💬';
  toggle.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    if (sidebar.classList.contains('open')) renderKpi(kpiContainer);
  });

  sidebar.appendChild(panel);
  sidebar.appendChild(toggle);
  document.body.appendChild(sidebar);
})();
