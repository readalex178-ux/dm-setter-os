const APP_URL = 'https://app.lovable.app/projects/dm-setter-os';

document.getElementById('open-app').href = APP_URL;

// KPI goals — read from storage (synced from page localStorage via content script)
// Fall back to chrome.storage.local where the content script can cache the value.
function renderKpi(goals) {
  const container = document.getElementById('kpi-container');
  container.innerHTML = '';
  if (!goals || Object.keys(goals).length === 0) {
    const p = document.createElement('p');
    p.className = 'no-goals';
    p.textContent = 'No KPI goals set yet. Open the app to configure.';
    container.appendChild(p);
    return;
  }
  const grid = document.createElement('div');
  grid.className = 'kpi-grid';
  Object.entries(goals).forEach(([key, val]) => {
    const row = document.createElement('div');
    row.className = 'kpi-row';
    row.innerHTML = `<span>${escapeHtml(String(key))}</span><span>${escapeHtml(String(val))}</span>`;
    grid.appendChild(row);
  });
  container.appendChild(grid);
}

function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

chrome.storage.local.get('dm_setter_kpi_goals', (result) => {
  renderKpi(result.dm_setter_kpi_goals || null);
});

// Quick log
document.getElementById('add-btn').addEventListener('click', () => {
  const input = document.getElementById('handle-input');
  const handle = input.value.trim().replace(/^@/, '');
  if (!handle) return;
  const url = `${APP_URL}?new_prospect=1&handle=${encodeURIComponent(handle)}`;
  chrome.tabs.create({ url });
  input.value = '';
  const toast = document.getElementById('toast');
  toast.style.display = 'block';
  setTimeout(() => { toast.style.display = 'none'; }, 2000);
});

document.getElementById('handle-input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') document.getElementById('add-btn').click();
});
