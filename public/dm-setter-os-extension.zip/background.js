// DM Setter OS — background service worker
chrome.runtime.onInstalled.addListener(() => {
  console.log('DM Setter OS extension installed.');
});
